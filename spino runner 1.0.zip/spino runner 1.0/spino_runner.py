import pygame
import random
import os

# ---------------------------
# Настройки окна и игры
# ---------------------------
WIDTH, HEIGHT = 800, 400
FPS = 60
TITLE = "Спинозавр: кактусы и птеранодоны"
ASSETS_DIR = "assets"
RECORD_FILE = "records.txt"

# ---------------------------
# Константы размеров
# ---------------------------
SPINO_STAND_W, SPINO_STAND_H = 50, 50
SPINO_DUCK_W,  SPINO_DUCK_H  = 64, 28
CACTUS_W,      CACTUS_H      = 22, 42
PTERA_W,       PTERA_H       = 48, 30

SCROLL_SPEED = 7
GRAVITY = 0.7
JUMP_V = 12.5
DISTANCE_SPEED = 20.0

# ---------------------------
# Цвета
# ---------------------------
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (120, 120, 120)

# ---------------------------
# Загрузка изображений
# ---------------------------
def load_image(name, size):
    path = os.path.join(ASSETS_DIR, name)
    img = pygame.image.load(path).convert_alpha()
    return pygame.transform.scale(img, size)

# ---------------------------
# Работа с рекордами
# ---------------------------
def load_records():
    if not os.path.exists(RECORD_FILE):
        return 0, 0
    try:
        with open(RECORD_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
        score = int(lines[0].split("=")[1]) if len(lines) > 0 else 0
        distance = int(lines[1].split("=")[1]) if len(lines) > 1 else 0
        return score, distance
    except:
        return 0, 0

def save_records(score, distance):
    with open(RECORD_FILE, "w", encoding="utf-8") as f:
        f.write(f"score={score}\n")
        f.write(f"distance={distance}\n")

# ---------------------------
# Игрок
# ---------------------------
class Player:
    def __init__(self, x=70):
        self.x = x
        self.on_ground = True
        self.vy = 0.0
        self.ducking = False

        self.image_stand = load_image("spino_stand.png", (SPINO_STAND_W, SPINO_STAND_H))
        self.image_duck = load_image("spino_duck.png", (SPINO_DUCK_W, SPINO_DUCK_H))

        self.rect = self.image_stand.get_rect()
        self.rect.left = self.x
        self.rect.bottom = HEIGHT

    def start_jump(self):
        if self.on_ground:
            self.on_ground = False
            self.ducking = False
            self.vy = -JUMP_V

    def update(self, keys):
        self.ducking = self.on_ground and (
            keys[pygame.K_s] or keys[pygame.K_DOWN] or keys[pygame.K_RCTRL]
        )

        if self.on_ground:
            if self.ducking:
                self.rect.size = (SPINO_DUCK_W, SPINO_DUCK_H)
            else:
                self.rect.size = (SPINO_STAND_W, SPINO_STAND_H)
            self.rect.left = self.x
            self.rect.bottom = HEIGHT
        else:
            self.rect.size = (SPINO_STAND_W, SPINO_STAND_H)

        if not self.on_ground:
            self.vy += GRAVITY
            self.rect.y += int(self.vy)
            if self.rect.bottom >= HEIGHT:
                self.rect.bottom = HEIGHT
                self.vy = 0.0
                self.on_ground = True

    def draw(self, surface):
        img = self.image_duck if self.ducking else self.image_stand
        surface.blit(img, self.rect)

# ---------------------------
# Препятствия
# ---------------------------
class Obstacle:
    def __init__(self, image, w, h):
        self.image = load_image(image, (w, h))
        self.rect = self.image.get_rect()
        self.rect.left = WIDTH

    def update(self):
        self.rect.x -= SCROLL_SPEED

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def is_offscreen(self):
        return self.rect.right < 0

class Cactus(Obstacle):
    def __init__(self):
        super().__init__("cactus.png", CACTUS_W, CACTUS_H)
        self.rect.bottom = HEIGHT

class Pteranodon(Obstacle):
    def __init__(self):
        super().__init__("pteranodon.png", PTERA_W, PTERA_H)
        y_min = HEIGHT - (SPINO_STAND_H + PTERA_H) + 1
        y_max = HEIGHT - SPINO_DUCK_H - 1 - PTERA_H
        y_min = max(0, y_min)
        y_max = min(HEIGHT - PTERA_H, y_max)
        if y_min > y_max:
            y_min, y_max = HEIGHT - 79, HEIGHT - 59
        self.rect.top = random.randint(y_min, y_max)

# ---------------------------
# Игровой цикл
# ---------------------------
def run_one_game(screen, clock, font):
    best_score, best_distance = load_records()
    player = Player()
    obstacles = []
    spawn_timer = 0
    next_spawn = random.randint(50, 95)
    score = 0
    distance = 0.0
    running = True

    while running:
        dt_ms = clock.tick(FPS)
        dt = dt_ms / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Сохраняем рекорд при выходе
                if score > best_score or int(distance) > best_distance:
                    save_records(max(score, best_score), max(int(distance), best_distance))
                return ("quit", score, int(distance))
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
                    player.start_jump()
                if event.key == pygame.K_ESCAPE:
                    # Сохраняем рекорд при выходе
                    if score > best_score or int(distance) > best_distance:
                        save_records(max(score, best_score), max(int(distance), best_distance))
                    return ("quit", score, int(distance))

        keys = pygame.key.get_pressed()
        player.update(keys)
        distance += DISTANCE_SPEED * dt

        spawn_timer += 1
        if spawn_timer >= next_spawn:
            allow_fliers = distance >= 500.0
            if allow_fliers and random.random() < 0.4:
                obstacles.append(Pteranodon())
            else:
                obstacles.append(Cactus())
            spawn_timer = 0
            next_spawn = random.randint(55, 100)

        for o in obstacles[:]:
            o.update()
            if o.is_offscreen():
                obstacles.remove(o)
                score += 1

        if any(o.rect.colliderect(player.rect) for o in obstacles):
            running = False

        screen.fill(BLACK)
        pygame.draw.line(screen, GREY, (0, HEIGHT - 1), (WIDTH, HEIGHT - 1), 2)
        player.draw(screen)
        for o in obstacles:
            o.draw(screen)

        dist_txt = int(distance)
        ui1 = font.render(f"Score: {score}   Distance: {dist_txt}", True, WHITE)
        ui2 = font.render(f"Best Score: {best_score}   Best Distance: {best_distance}", True, WHITE)
        ui3 = font.render("W/↑/Space: jump   S/↓/Right Ctrl: duck   ESC: exit", True, WHITE)
        screen.blit(ui1, (10, 10))
        screen.blit(ui2, (10, 35))
        screen.blit(ui3, (10, 60))
        pygame.display.flip()

    # Сохраняем рекорд после столкновения
    if score > best_score or int(distance) > best_distance:
        save_records(max(score, best_score), max(int(distance), best_distance))

    return game_over_screen(screen, clock, font, score, int(distance))

def game_over_screen(screen, clock, font, score, distance):
    title = font.render("Game Over", True, WHITE)
    info1 = font.render(f"Score: {score}   Distance: {distance}", True, WHITE)
    info2 = font.render("Нажми R для перезапуска или Esc для выхода", True, WHITE)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return ("quit", score, distance)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return ("quit", score, distance)
                if event.key == pygame.K_r:
                    return ("restart", score, distance)

        screen.fill(BLACK)
        y = HEIGHT // 2 - 30
        screen.blit(title, title.get_rect(center=(WIDTH // 2, y)))
        screen.blit(info1, info1.get_rect(center=(WIDTH // 2, y + 30)))
        screen.blit(info2, info2.get_rect(center=(WIDTH // 2, y + 60)))
        pygame.display.flip()
        clock.tick(30)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(TITLE)
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("arial", 20)

    while True:
        action, _, _ = run_one_game(screen, clock, font)
        if action == "quit":
            break

    pygame.quit()

if __name__ == "__main__":
    main()
